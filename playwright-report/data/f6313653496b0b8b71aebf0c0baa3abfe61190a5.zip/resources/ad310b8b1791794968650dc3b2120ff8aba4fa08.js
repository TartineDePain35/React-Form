"use strict";
(globalThis["webpackChunktodo_formation_react"] = globalThis["webpackChunktodo_formation_react"] || []).push([["src_tasks_json"],{

/***/ "./src/tasks.json":
/*!************************!*\
  !*** ./src/tasks.json ***!
  \************************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"tasks":[{"id":1,"createDate":"23/04/2025","title":"Première tache","done":false,"detail":"Lorem Ipsum is simply dummy text of the printing and typesetting industry."},{"id":1,"createDate":"23/04/2025","title":"Deuxième tache","done":false,"detail":"Lorem Ipsum is simply dummy text of the printing and typesetting industry."},{"id":1,"createDate":"23/04/2025","title":"Troisième tache","done":true,"detail":"Lorem Ipsum is simply dummy text of the printing and typesetting industry."}]}');

/***/ })

}]);